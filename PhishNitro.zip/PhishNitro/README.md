# FreefirePisher

Es un pishsing de freefire usando como tunel ngrok no recomiendo usar el shortener.
![Texto alternativo](https://github.com/p1ngu1n0/FreefirePisher/blob/master/Screenshot_2020-04-12%20Free%20Fire%20-%20Battlegrounds%20Hack%20Generator%20-%20Unlimited%20Money%20Cheats.png)
![Texto alternativo](https://github.com/p1ngu1n0/FreefirePisher/blob/master/test.png)


  install:
  

    git clone https://github.com/p1ngu1n0/FreefirePisher.git
    cd FreefirePisher
    bash FreefirePisher.sh
